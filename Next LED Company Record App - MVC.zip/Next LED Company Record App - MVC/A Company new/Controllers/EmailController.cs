﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using A_Company_new.Models;

namespace A_Company_new.Controllers
{
    public class EmailController : Controller
    {
        private customerInfoDB db = new customerInfoDB();

        //
        // GET: /Email/

        public ActionResult Index(int id)
        {
            ViewBag.Id = id;
            var info = from name in db.saleEmailEntry
                       select name;
                info = info.Where(s => s.ID_Customer.Equals(id));

            return View(info);
        }

        //
        // GET: /Email/Details/5

        public ActionResult Details(int id = 0)
        {
            saleEmailEntry saleemailentry = db.saleEmailEntry.Find(id);
            if (saleemailentry == null)
            {
                return HttpNotFound();
            }
            return View(saleemailentry);
        }

        //
        // GET: /Email/Create

        public ActionResult Create(int id)
        {
            ViewBag.Id = id;
            return View();
        }

        //
        // POST: /Email/Create

        [HttpPost]
        public ActionResult Create(saleEmailEntry saleemailentry)
        {
            if (ModelState.IsValid)
            {
                db.saleEmailEntry.Add(saleemailentry);
                db.SaveChanges();
                return RedirectToAction("Index", new { id = saleemailentry.ID_Customer });
            }

            return View(saleemailentry);
        }

        //
        // GET: /Email/Edit/5

        public ActionResult Edit(int id = 0)
        {
            saleEmailEntry saleemailentry = db.saleEmailEntry.Find(id);
            if (saleemailentry == null)
            {
                return HttpNotFound();
            }
            return View(saleemailentry);
        }

        //
        // POST: /Email/Edit/5

        [HttpPost]
        public ActionResult Edit(saleEmailEntry saleemailentry)
        {
            if (ModelState.IsValid)
            {
                db.Entry(saleemailentry).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", new {id= saleemailentry.ID_Customer });
            }
            return View(saleemailentry);
        }

        //
        // GET: /Email/Delete/5

        public ActionResult Delete(int id = 0)
        {
            saleEmailEntry saleemailentry = db.saleEmailEntry.Find(id);
            if (saleemailentry == null)
            {
                return HttpNotFound();
            }
            return View(saleemailentry);
        }

        //
        // POST: /Email/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            saleEmailEntry saleemailentry = db.saleEmailEntry.Find(id);
            db.saleEmailEntry.Remove(saleemailentry);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}