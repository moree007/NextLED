﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using A_Company_new.Models;

namespace A_Company_new.Controllers
{
    public class VoiceController : Controller
    {
        private customerInfoDB db = new customerInfoDB();

        //
        // GET: /Voice/

        public ActionResult Index(int id)
        {
            ViewBag.Id = id;
            var info = from name in db.saleVoiceEntry
                       select name;
            info = info.Where(s => s.ID_Cust.Equals(id));

            return View(info);
        }

        //
        // GET: /Voice/Details/5

        public ActionResult Details(int id = 0)
        {
            saleVoiceEntry salevoiceentry = db.saleVoiceEntry.Find(id);
            if (salevoiceentry == null)
            {
                return HttpNotFound();
            }
            return View(salevoiceentry);
        }

        //
        // GET: /Voice/Create

        public ActionResult Create(int id)
        {
            ViewBag.Id = id;
            return View();
        }

        //
        // POST: /Voice/Create

        [HttpPost]
        public ActionResult Create(saleVoiceEntry salevoiceentry)
        {
            if (ModelState.IsValid)
            {
                db.saleVoiceEntry.Add(salevoiceentry);
                db.SaveChanges();
                return RedirectToAction("Index", new { id = salevoiceentry.ID_Cust });
            }

            return View(salevoiceentry);
        }

        //
        // GET: /Voice/Edit/5

        public ActionResult Edit(int id = 0)
        {
            saleVoiceEntry salevoiceentry = db.saleVoiceEntry.Find(id);
            if (salevoiceentry == null)
            {
                return HttpNotFound();
            }
            return View(salevoiceentry);
        }

        //
        // POST: /Voice/Edit/5

        [HttpPost]
        public ActionResult Edit(saleVoiceEntry salevoiceentry)
        {
            if (ModelState.IsValid)
            {
                db.Entry(salevoiceentry).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", new { id = salevoiceentry.ID_Cust });
            }
            return View(salevoiceentry);
        }

        //
        // GET: /Voice/Delete/5

        public ActionResult Delete(int id = 0)
        {
            saleVoiceEntry salevoiceentry = db.saleVoiceEntry.Find(id);
            if (salevoiceentry == null)
            {
                return HttpNotFound();
            }
            return View(salevoiceentry);
        }

        //
        // POST: /Voice/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            saleVoiceEntry salevoiceentry = db.saleVoiceEntry.Find(id);
            db.saleVoiceEntry.Remove(salevoiceentry);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}