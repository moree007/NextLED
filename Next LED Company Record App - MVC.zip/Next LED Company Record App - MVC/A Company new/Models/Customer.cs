﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace A_Company_new.Models
{
    [DisplayName("Customer Info")]
    public class Customer
    {
        public int ID { get; set; }
        [DisplayName("Company Name")]
        public string CompanyName { get; set; }
        [DisplayName("Contact Name")]
        public string ContactName { get; set; }
        public DateTime Date { get; set; }
        public string Address { get; set; }
    }

    public class saleEmailEntry
    {
        public int ID { get; set; }
        public int ID_Customer { get; set; }
        public TimeSpan Time { get; set; }
        [DisplayName("Responded Back")]
        public bool Response { get; set; }
        [DisplayName("Email Address")]
        public string EmailAddress { get; set; }
        [DisplayName("Email Subject")]
        public string EmailSubject { get; set; }
        [DisplayName("Email Message")]
        [DataType(DataType.MultilineText)]
        public string EmailMessage { get; set; }
    }

    public class saleVoiceEntry
    {
        public int ID { get; set; }
        public int ID_Cust { get; set; }
        public TimeSpan Time { get; set; }
        [DisplayName("Respond Back")]
        public bool Response { get; set; }
        [DisplayName("Email Address")]
        public string EmailAddress { get; set; }
        [DisplayName("Email Subject")]
        public string EmailSubject { get; set; }
        [DisplayName("Email Message")]
        [DataType(DataType.MultilineText)]
        public string EmailMessage { get; set; }
    }

    public class customerInfoDB : DbContext
    {
        public DbSet<Customer> Customer { get; set; }
        public DbSet<saleEmailEntry> saleEmailEntry { get; set; }
        public DbSet<saleVoiceEntry> saleVoiceEntry { get; set; }
    }

}