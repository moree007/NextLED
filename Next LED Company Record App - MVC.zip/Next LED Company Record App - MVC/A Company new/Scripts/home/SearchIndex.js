﻿$(document).ready(function () {
    $('.anchor-button').click(function () {
        var new_location = $(this).find('a').attr('href');
        window.location = new_location;
    });
});